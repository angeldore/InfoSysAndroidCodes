# JavaWithAndroidPeople
THis is for studical purpose of java class badge 12
