package com.infosys.gridpractice;

/**
 * Created by mac on 21/02/2018.
 */

public class GridDataModel {

    public String ImageUrl;
    public String ImageTitle;

    public GridDataModel(String imageUrl, String imageTitle) {
        ImageUrl = imageUrl;
        ImageTitle = imageTitle;
    }
}
