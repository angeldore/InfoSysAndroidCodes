package com.braniax.volleylibproject.dataModels;

/**
 * Created by mac on 27/02/2018.
 */

public class UserClassModel {

    public String userImageUrl;
    public String userName;
    public String userDesignation;

    public UserClassModel(String userImageUrl, String userName, String userDesignation) {
        this.userImageUrl = userImageUrl;
        this.userName = userName;
        this.userDesignation = userDesignation;
    }


}
